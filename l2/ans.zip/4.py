name=input("Name: ")
tp=input("TP Number: ")
mark=int(input("Mark: "))
grade=input("Grade: ")

print(name, tp, mark, grade)

# print(input("Name: "), input("TP Number: "), int(input("Mark: ")), input("Grade: "))