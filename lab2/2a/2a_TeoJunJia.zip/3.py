sentence=input("Please enter a sentence: \n")

if "python" in sentence.lower():
    print("The sentence contains the word Python.")
else:
    print("The sentence does not contain the word Python.")